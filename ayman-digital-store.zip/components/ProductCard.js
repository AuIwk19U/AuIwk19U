
import { Box, Image, Text, Button, Stack } from '@chakra-ui/react';
import Link from 'next/link';

export default function ProductCard({ product }) {
  return (
    <Box bg='blue.900' color='white' borderRadius='xl' p={4}>
      <Image src={product.image} alt={product.name} borderRadius='lg' />
      <Stack spacing={2} mt={3}>
        <Text fontWeight='bold'>{product.name}</Text>
        <Text fontSize='sm'>{product.description}</Text>
        <Text fontWeight='bold'>{product.price} د.إ</Text>
        <Link href={`/product/${product.id}`} passHref legacyBehavior>
          <Button bg='blue.600' _hover={{ bg: 'blue.500' }} w='full'>
            شراء
          </Button>
        </Link>
      </Stack>
    </Box>
  );
}
