
# Ayman Digital Store

متجر رقمي بلون أزرق داكن مبني على Next.js + React.

## خطوات التشغيل محلياً

```bash
npm install
npm run dev
```

## خطوات النشر على Vercel

1. ادخل إلى https://vercel.com وسجّل الدخول بالإيميل.
2. اضغط "New Project" ثم "Import".
3. اختر "Upload" وارفع ملف المشروع المضغوط بعد فكّه.
4. اضغط Deploy وانتظر ثوانٍ ليصبح رابط متجرك جاهزاً.

لوحة الإدارة متاحة على `/admin`  
كلمة المرور الافتراضية: `Admin@123`
