
import { useRouter } from 'next/router';
import products from '../data/products.json';
import { Container, Heading, Text, Input, Stack, Button } from '@chakra-ui/react';
import { useState } from 'react';

export default function Checkout() {
  const router = useRouter();
  const { product: productId } = router.query;
  const product = products.find(p => p.id === productId);
  const [email, setEmail] = useState('');

  if (!product) return <Text>لا يوجد منتج</Text>;

  const handleOrder = () => {
    alert('تم إنشاء طلبك! سيتم التواصل معك على بريدك');
    router.push('/');
  };

  return (
    <Container maxW='container.sm' py={10}>
      <Heading mb={6}>إتمام الشراء</Heading>
      <Stack spacing={4}>
        <Text>{product.name}</Text>
        <Text fontWeight='bold'>{product.price} د.إ</Text>
        <Input placeholder='البريد الإلكتروني' value={email} onChange={e => setEmail(e.target.value)} />
        <Input placeholder='كود الخصم (إن وجد)' />
        <Button bg='blue.600' _hover={{bg:'blue.500'}} onClick={handleOrder}>إتمام الطلب</Button>
      </Stack>
    </Container>
  );
}
