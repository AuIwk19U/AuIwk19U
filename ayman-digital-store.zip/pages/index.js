
import { Container, Grid, Heading } from '@chakra-ui/react';
import ProductCard from '../components/ProductCard';
import products from '../data/products.json';

export default function Home() {
  return (
    <Container maxW='container.xl' py={10}>
      <Heading mb={6} textAlign='center'>المنتجات الرقمية</Heading>
      <Grid templateColumns={['repeat(1,1fr)','repeat(2,1fr)','repeat(3,1fr)']} gap={6}>
        {products.map(p => <ProductCard key={p.id} product={p} />)}
      </Grid>
    </Container>
  );
}
