
import { useRouter } from 'next/router';
import products from '../../data/products.json';
import { Container, Text, Image, Stack, Button } from '@chakra-ui/react';
import Link from 'next/link';

export default function ProductPage() {
  const { query } = useRouter();
  const product = products.find(p => p.id === query.id);
  if (!product) return <Text>المنتج غير موجود</Text>;

  return (
    <Container maxW='container.md' py={10}>
      <Image src={product.image} alt={product.name} borderRadius='lg' />
      <Stack mt={4} spacing={3}>
        <Text fontSize='2xl' fontWeight='bold'>{product.name}</Text>
        <Text>{product.description}</Text>
        <Text fontWeight='bold'>{product.price} د.إ</Text>
        <Link href={`/checkout?product=${product.id}`} passHref legacyBehavior>
          <Button bg='blue.600' _hover={{bg:'blue.500'}}>شراء الآن</Button>
        </Link>
      </Stack>
    </Container>
  );
}
