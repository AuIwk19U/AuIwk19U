
import { Container, Heading, Text } from '@chakra-ui/react';

export default function Privacy() {
  return (
    <Container maxW='container.md' py={10}>
      <Heading mb={6}>سياسة الخصوصية</Heading>
      <Text>نحترم خصوصيتك ولن نشارك بياناتك مع طرف ثالث.</Text>
    </Container>
  );
}
