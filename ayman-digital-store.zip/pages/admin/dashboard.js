
import { useEffect } from 'react';
import { useRouter } from 'next/router';
import products from '../../data/products.json';
import { Container, Heading, SimpleGrid, Box, Text, Button } from '@chakra-ui/react';

export default function Dashboard() {
  const router = useRouter();
  useEffect(() => {
    if (typeof window !== 'undefined' && localStorage.getItem('admin') !== 'true') {
      router.push('/admin');
    }
  }, []);

  return (
    <Container maxW='container.lg' py={10}>
      <Heading mb={6}>لوحة الإدارة</Heading>
      <SimpleGrid columns={[1,2,3]} spacing={6}>
        {products.map(p => (
          <Box key={p.id} bg='blue.900' p={4} borderRadius='lg' color='white'>
            <Text fontWeight='bold'>{p.name}</Text>
            <Text>{p.price} د.إ</Text>
          </Box>
        ))}
      </SimpleGrid>
    </Container>
  );
}
