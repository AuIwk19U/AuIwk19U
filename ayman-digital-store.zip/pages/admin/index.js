
import { useState } from 'react';
import { Container, Heading, Input, Button, Stack } from '@chakra-ui/react';
import Link from 'next/link';

export default function AdminLogin() {
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (password === 'Admin@123') {
      localStorage.setItem('admin', 'true');
      window.location.href = '/admin/dashboard';
    } else {
      alert('كلمة مرور خاطئة');
    }
  };

  return (
    <Container maxW='container.sm' py={10}>
      <Heading mb={6}>تسجيل دخول المشرف</Heading>
      <Stack spacing={4}>
        <Input type='password' placeholder='كلمة المرور' value={password} onChange={e=>setPassword(e.target.value)} />
        <Button bg='blue.600' _hover={{bg:'blue.500'}} onClick={handleLogin}>دخول</Button>
      </Stack>
    </Container>
  );
}
