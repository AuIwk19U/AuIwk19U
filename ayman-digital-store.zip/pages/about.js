
import { Container, Heading, Text } from '@chakra-ui/react';

export default function About() {
  return (
    <Container maxW='container.md' py={10}>
      <Heading mb={6}>من نحن</Heading>
      <Text>هذا متجر رقمي لبيع الاشتراكات والحسابات بأفضل الأسعار.</Text>
    </Container>
  );
}
